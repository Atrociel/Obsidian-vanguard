export enum ClassType {
    SOUL_REAPER = 'Soul Reaper',
    SLAYER = 'Slayer',
    SORCERER = 'Sorcerer'
}

export enum ElementType {
    FIRE = 'Fire',
    WATER = 'Water',
    ICE = 'Ice',
    WIND = 'Wind',
    EARTH = 'Earth',
    DARKNESS = 'Darkness',
    LIGHT = 'Light',
    POISON = 'Poison',
    VOID = 'Void'
}

export interface StatBonuses {
    allStats?: number; // percentage
    maxHealth?: number; // percentage
    damageReduction?: number; // percentage
    lifeSteal?: number; // percentage
    damageReflex?: number; // percentage
    manaRegen?: number; // percentage
    cooldownReduction?: number; // percentage
}

export interface SetBonus {
    pieces: number;
    name: string;
    description: string;
}

export interface GodTierSet {
    name: string;
    description: string;
    globalStats: StatBonuses;
    pieces: string[];
    bonuses: SetBonus[];
}

export interface ClassDefinition {
    type: ClassType;
    description: string;
    role: string;
    resource: string;
    elements: ElementType[];
    godTierSet: GodTierSet;
}

export const CLASSES: Record<ClassType, ClassDefinition> = {
    [ClassType.SOUL_REAPER]: {
        type: ClassType.SOUL_REAPER,
        role: 'Necro-Assassin',
        description: 'Master brutal, kinetic combat, forge God-Tier gear, and bind ancient powers to your will.',
        resource: 'Souls',
        elements: [ElementType.DARKNESS, ElementType.VOID, ElementType.POISON],
        godTierSet: {
            name: 'The Thanatos Shroud Set',
            description: 'Biological Horror & Ethereal Speed.',
            globalStats: {
                allStats: 800,
                lifeSteal: 240,
                damageReflex: 240
            },
            pieces: [
                'Cowl of the Lich Lord', 'Spines of the Necrolord', 'Ribcage of the Eternal',
                'Grips of the Grave', 'Treads of the Phantom', 'Soul-Reaper\'s Edge',
                'Grim Codex of Whispers', 'The Void Heart Phylactery', 'Shackles of the Unbound',
                'Signet of the Alpha', 'Signet of the Omega', 'Shadow-Warped Sigil'
            ],
            bonuses: [
                { pieces: 2, name: 'Vampiric Command', description: 'Minions gain 100% Life Steal.' },
                { pieces: 12, name: 'Lich Lord\'s Dominion', description: 'Legion grants True Damage and chain attacks.' }
            ]
        }
    },
    [ClassType.SLAYER]: {
        type: ClassType.SLAYER,
        role: 'Tank / Berserker',
        description: 'Immense durability, taunting enemies, absorbing massive damage.',
        resource: 'Fury',
        elements: [ElementType.FIRE, ElementType.EARTH], // Iron is mapped to physical/earth conceptually or we can add it. Keeping simple for now.
        godTierSet: {
            name: 'The World-Breaker’s Plate Set',
            description: 'Molten Indestructibility.',
            globalStats: {
                allStats: 800,
                maxHealth: 500,
                damageReduction: 90
            },
            pieces: [
                'World-Breaker Helm', 'World-Breaker Pauldrons', 'World-Breaker Cuirass',
                'World-Breaker Gauntlets', 'World-Breaker Greaves', 'World Cleaver',
                'Stone Ward of Resilience', 'Heart of the Mountain', 'Shackles of the Stone God',
                'Band of the Black Star', 'Oath Ring of the Colossus', 'Earthen Core Shard'
            ],
            bonuses: [
                { pieces: 2, name: 'Unstoppable Force', description: 'Immunity to Crowd Control.' },
                { pieces: 12, name: 'World-Breaker\'s Decree', description: 'Permanent Invincibility in Titan Form.' }
            ]
        }
    },
    [ClassType.SORCERER]: {
        type: ClassType.SORCERER,
        role: 'Ranged AoE / Crowd Control',
        description: 'High burst spell damage, strategic positioning.',
        resource: 'Mana & Heat',
        elements: [ElementType.VOID, ElementType.ICE, ElementType.WIND], // Wind/Lightning mapped together usually
        godTierSet: {
            name: 'The Event Horizon Regalia Set',
            description: 'Cosmic Erasure.',
            globalStats: {
                allStats: 800,
                manaRegen: 10000,
                cooldownReduction: 80
            },
            pieces: [
                'Helm of the Event Horizon', 'Spaulders of the Singularity', 'Robes of Cosmic Erasure',
                'Gauntlets of Celestial Weaving', 'Greaves of Pure Energy', 'Orb of Absolute Power',
                'Grimoire of Unmaking', 'Eye of the Creator', 'Bracelet of Entropic Flow',
                'Loop of Infinity', 'Ring of the Celestial Conductor', 'Astral Conflux Shard'
            ],
            bonuses: [
                { pieces: 2, name: 'Spell Weaver', description: '50% chance to Double Cast.' },
                { pieces: 12, name: 'Absolute Erasure', description: 'Become pure energy, unleash Obliterate beam.' }
            ]
        }
    }
};

export enum SocketEvents {
    CONNECT = 'connect',
    DISCONNECT = 'disconnect',
    JOIN_GAME = 'join_game',
    PLAYER_JOINED = 'player_joined',
    PLAYER_MOVED = 'player_moved',
    PLAYER_LEFT = 'player_left',
    CHAOS_ARRAY_UPDATE = 'chaos_array_update',
    CHAT_MESSAGE = 'chat_message'
}

export interface PlayerState {
    id: string;
    name: string;
    classType: ClassType;
    x: number;
    y: number;
    hp: number;
    maxHp: number;
}
