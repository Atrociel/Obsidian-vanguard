import React, { useState, useEffect, useRef } from 'react';
import { io, Socket } from 'socket.io-client';
import { SocketEvents, ClassType, CLASSES, PlayerState } from '@obsidian-vanguard/shared';
import { Sword, Skull, Zap, Shield, Sparkles } from 'lucide-react';
import { motion } from 'framer-motion';

const socket: Socket = io(); // Connects to same host/port by default via proxy

function App() {
  const [gameState, setGameState] = useState<'SELECT' | 'GAME'>('SELECT');
  const [selectedClass, setSelectedClass] = useState<ClassType>(ClassType.SOUL_REAPER);
  const [playerName, setPlayerName] = useState('VoidWalker');
  const [players, setPlayers] = useState<Record<string, PlayerState>>({});
  const [myId, setMyId] = useState<string | null>(null);
  const [chaosActive, setChaosActive] = useState(false);

  useEffect(() => {
    socket.on(SocketEvents.CONNECT, () => {
      console.log('Connected to server');
    });

    socket.on(SocketEvents.JOIN_GAME, (data: { players: Record<string, PlayerState>, id: string }) => {
        setPlayers(data.players);
        setMyId(data.id);
        setGameState('GAME');
    });

    socket.on(SocketEvents.PLAYER_JOINED, (player: PlayerState) => {
        setPlayers(prev => ({ ...prev, [player.id]: player }));
    });

    socket.on(SocketEvents.PLAYER_MOVED, (data: { id: string, x: number, y: number }) => {
        setPlayers(prev => {
            if (!prev[data.id]) return prev;
            return {
                ...prev,
                [data.id]: { ...prev[data.id], x: data.x, y: data.y }
            };
        });
    });

    socket.on(SocketEvents.PLAYER_LEFT, (data: { id: string }) => {
        setPlayers(prev => {
            const newPlayers = { ...prev };
            delete newPlayers[data.id];
            return newPlayers;
        });
    });

    socket.on(SocketEvents.CHAOS_ARRAY_UPDATE, (data: { active: boolean, duration?: number }) => {
        setChaosActive(data.active);
    });

    return () => {
        socket.off(SocketEvents.CONNECT);
        socket.off(SocketEvents.JOIN_GAME);
        socket.off(SocketEvents.PLAYER_JOINED);
        socket.off(SocketEvents.PLAYER_MOVED);
        socket.off(SocketEvents.PLAYER_LEFT);
        socket.off(SocketEvents.CHAOS_ARRAY_UPDATE);
    };
  }, []);

  const handleJoin = () => {
      socket.emit(SocketEvents.JOIN_GAME, { name: playerName, classType: selectedClass });
  };

  return (
    <div className="w-full h-screen bg-obsidian-black text-gray-200 font-sans overflow-hidden">
        {gameState === 'SELECT' ? (
            <CharacterSelection 
                selectedClass={selectedClass} 
                setSelectedClass={setSelectedClass}
                playerName={playerName}
                setPlayerName={setPlayerName}
                onJoin={handleJoin}
            />
        ) : (
            <GameWorld 
                players={players} 
                myId={myId} 
                chaosActive={chaosActive}
            />
        )}
    </div>
  );
}

function CharacterSelection({ selectedClass, setSelectedClass, playerName, setPlayerName, onJoin }: any) {
    const classInfo = CLASSES[selectedClass as ClassType];

    return (
        <div className="flex flex-col items-center justify-center h-full p-8 bg-[radial-gradient(ellipse_at_center,_var(--tw-gradient-stops))] from-gray-900 via-[#050505] to-black">
            <h1 className="text-5xl font-gothic text-gold-accent mb-8 tracking-widest uppercase">Obsidian Vanguard</h1>
            
            <div className="grid grid-cols-1 md:grid-cols-3 gap-8 w-full max-w-6xl">
                {/* Class List */}
                <div className="space-y-4">
                    <h2 className="text-2xl font-gothic text-gray-400 border-b border-gray-800 pb-2">Select Class</h2>
                    {Object.values(CLASSES).map((cls) => (
                        <button
                            key={cls.type}
                            onClick={() => setSelectedClass(cls.type)}
                            className={`w-full text-left p-4 border transition-all duration-300 ${
                                selectedClass === cls.type 
                                ? 'border-gold-accent bg-gold-accent/10 text-gold-accent shadow-[0_0_15px_rgba(212,175,55,0.3)]' 
                                : 'border-gray-800 hover:border-gray-600 text-gray-500'
                            }`}
                        >
                            <div className="font-bold text-lg">{cls.type}</div>
                            <div className="text-xs opacity-70">{cls.role}</div>
                        </button>
                    ))}
                </div>

                {/* Class Details */}
                <div className="col-span-2 bg-obsidian-dark border border-gray-800 p-6 relative overflow-hidden">
                    <div className="absolute top-0 right-0 p-4 opacity-10">
                        {selectedClass === ClassType.SOUL_REAPER && <Skull size={200} />}
                        {selectedClass === ClassType.SLAYER && <Shield size={200} />}
                        {selectedClass === ClassType.SORCERER && <Zap size={200} />}
                    </div>
                    
                    <h2 className="text-4xl font-gothic text-white mb-2">{classInfo.type}</h2>
                    <p className="text-gold-accent mb-4 font-serif italic">{classInfo.role}</p>
                    <p className="text-gray-400 mb-6 leading-relaxed">{classInfo.description}</p>
                    
                    <div className="grid grid-cols-2 gap-6">
                        <div>
                            <h3 className="text-sm uppercase tracking-wider text-gray-500 mb-2">Primary Elements</h3>
                            <div className="flex gap-2">
                                {classInfo.elements.map(el => (
                                    <span key={el} className="px-2 py-1 bg-gray-900 border border-gray-700 text-xs rounded text-gray-300">{el}</span>
                                ))}
                            </div>
                        </div>
                        <div>
                            <h3 className="text-sm uppercase tracking-wider text-gray-500 mb-2">Resource</h3>
                            <span className="text-gray-300">{classInfo.resource}</span>
                        </div>
                    </div>

                    <div className="mt-8 border-t border-gray-800 pt-6">
                        <div className="flex items-center gap-2 mb-4 text-purple-400">
                            <Sparkles size={18} />
                            <h3 className="font-gothic text-lg">God Tier Set: {classInfo.godTierSet.name}</h3>
                        </div>
                        <div className="bg-gray-900/50 p-4 rounded border border-gray-800 text-sm space-y-2">
                            <p className="italic text-gray-500">"{classInfo.godTierSet.description}"</p>
                            <div className="grid grid-cols-2 gap-4 mt-2">
                                <ul className="list-disc list-inside text-gray-400">
                                    <li>2-Pc: {classInfo.godTierSet.bonuses[0].name}</li>
                                    <li>12-Pc: {classInfo.godTierSet.bonuses[1].name}</li>
                                </ul>
                                <div className="text-right text-gray-500 text-xs">
                                    Global Stats: +{classInfo.godTierSet.globalStats.allStats}% All Stats
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <div className="mt-12 flex gap-4">
                <input 
                    type="text" 
                    value={playerName} 
                    onChange={(e) => setPlayerName(e.target.value)}
                    className="bg-transparent border-b-2 border-gray-700 px-4 py-2 outline-none text-center text-xl focus:border-gold-accent transition-colors"
                    placeholder="Enter Name"
                />
                <button 
                    onClick={onJoin}
                    className="px-8 py-2 bg-gold-accent text-black font-bold uppercase tracking-widest hover:bg-white transition-colors"
                >
                    Enter Realm
                </button>
            </div>
        </div>
    );
}

function GameWorld({ players, myId, chaosActive }: { players: Record<string, PlayerState>, myId: string | null, chaosActive: boolean }) {
    const canvasRef = useRef<HTMLCanvasElement>(null);
    const keysPressed = useRef<Record<string, boolean>>({});

    // Input handling
    useEffect(() => {
        const handleKeyDown = (e: KeyboardEvent) => { keysPressed.current[e.key] = true; };
        const handleKeyUp = (e: KeyboardEvent) => { keysPressed.current[e.key] = false; };
        window.addEventListener('keydown', handleKeyDown);
        window.addEventListener('keyup', handleKeyUp);
        return () => {
            window.removeEventListener('keydown', handleKeyDown);
            window.removeEventListener('keyup', handleKeyUp);
        };
    }, []);

    // Game Loop
    useEffect(() => {
        if (!myId || !players[myId]) return;

        let animationFrameId: number;

        const update = () => {
            const player = players[myId];
            const speed = 5;
            let dx = 0;
            let dy = 0;

            if (keysPressed.current['w'] || keysPressed.current['ArrowUp']) dy -= speed;
            if (keysPressed.current['s'] || keysPressed.current['ArrowDown']) dy += speed;
            if (keysPressed.current['a'] || keysPressed.current['ArrowLeft']) dx -= speed;
            if (keysPressed.current['d'] || keysPressed.current['ArrowRight']) dx += speed;

            if (dx !== 0 || dy !== 0) {
                const newX = player.x + dx;
                const newY = player.y + dy;
                // Simple prediction / immediate update
                socket.emit(SocketEvents.PLAYER_MOVED, { x: newX, y: newY });
                // We optimistically update locally in the render loop, but the authoritative source is the state
                // For this prototype, we rely on the state updates from socket or local optimistic if needed
                // But since we set state on socket event, we might feel lag. 
                // Let's implement local optimistic update for smoothness in next step if needed. 
                // For now, simple emit.
            }
        };

        const render = () => {
            const canvas = canvasRef.current;
            if (!canvas) return;
            const ctx = canvas.getContext('2d');
            if (!ctx) return;

            // Clear
            ctx.fillStyle = '#111';
            ctx.fillRect(0, 0, canvas.width, canvas.height);

            // Draw Grid
            ctx.strokeStyle = '#222';
            ctx.lineWidth = 1;
            for (let i = 0; i < canvas.width; i += 50) {
                ctx.beginPath();
                ctx.moveTo(i, 0);
                ctx.lineTo(i, canvas.height);
                ctx.stroke();
            }
            for (let i = 0; i < canvas.height; i += 50) {
                ctx.beginPath();
                ctx.moveTo(0, i);
                ctx.lineTo(canvas.width, i);
                ctx.stroke();
            }

            // Draw Players
            Object.values(players).forEach(p => {
                const isMe = p.id === myId;
                
                // Shadow
                ctx.fillStyle = 'rgba(0,0,0,0.5)';
                ctx.beginPath();
                ctx.ellipse(p.x, p.y + 15, 10, 5, 0, 0, Math.PI * 2);
                ctx.fill();

                // Character
                ctx.fillStyle = isMe ? '#d4af37' : '#666';
                if (p.classType === ClassType.SOUL_REAPER) ctx.fillStyle = isMe ? '#00ff9d' : '#2e7d32'; // Greenish
                if (p.classType === ClassType.SLAYER) ctx.fillStyle = isMe ? '#ff5722' : '#bf360c'; // Reddish
                if (p.classType === ClassType.SORCERER) ctx.fillStyle = isMe ? '#4a148c' : '#311b92'; // Purpleish

                ctx.beginPath();
                ctx.arc(p.x, p.y, 15, 0, Math.PI * 2);
                ctx.fill();

                // Name
                ctx.fillStyle = '#fff';
                ctx.font = '12px Inter';
                ctx.textAlign = 'center';
                ctx.fillText(p.name, p.x, p.y - 25);
                
                // HP Bar
                ctx.fillStyle = '#333';
                ctx.fillRect(p.x - 15, p.y - 20, 30, 4);
                ctx.fillStyle = '#d32f2f';
                ctx.fillRect(p.x - 15, p.y - 20, 30 * (p.hp / p.maxHp), 4);
            });

            // Chaos Array Visual
            if (chaosActive) {
                ctx.fillStyle = 'rgba(74, 20, 140, 0.2)'; // Void purple overlay
                ctx.fillRect(0, 0, canvas.width, canvas.height);
                
                ctx.font = '40px Cinzel';
                ctx.fillStyle = '#d4af37';
                ctx.textAlign = 'center';
                ctx.fillText("CHAOS ARRAY ACTIVE", canvas.width / 2, 100);
                
                ctx.font = '20px Cinzel';
                ctx.fillStyle = '#fff';
                ctx.fillText("Elements Nullified", canvas.width / 2, 140);
            }

            update();
            animationFrameId = requestAnimationFrame(render);
        };

        render();

        return () => cancelAnimationFrame(animationFrameId);
    }, [players, myId, chaosActive]);

    return (
        <div className="relative w-full h-full flex items-center justify-center bg-black">
             <canvas 
                ref={canvasRef} 
                width={800} 
                height={600} 
                className="border border-gray-800 bg-obsidian-black shadow-2xl"
            />
            
            {/* HUD Overlay */}
            <div className="absolute top-4 left-4 p-4 bg-black/50 border border-gray-800 text-white">
                <h3 className="font-gothic text-gold-accent">Player Stats</h3>
                {myId && players[myId] && (
                    <div className="text-sm">
                        <p>{players[myId].name}</p>
                        <p className="text-gray-400">{players[myId].classType}</p>
                        <p>HP: {players[myId].hp} / {players[myId].maxHp}</p>
                    </div>
                )}
            </div>
        </div>
    );
}

export default App;
