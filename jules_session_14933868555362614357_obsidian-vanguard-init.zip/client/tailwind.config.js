/** @type {import('tailwindcss').Config} */
export default {
  content: [
    "./index.html",
    "./src/**/*.{js,ts,jsx,tsx}",
  ],
  theme: {
    extend: {
      colors: {
        'obsidian-black': '#0a0a0a',
        'obsidian-dark': '#111111',
        'blood-red': '#8a1c1c',
        'void-purple': '#4a148c',
        'spectral-green': '#00ff9d',
        'gold-accent': '#d4af37',
      },
      fontFamily: {
        'gothic': ['Cinzel', 'serif'], // Assuming we can import a font or fallback
        'sans': ['Inter', 'sans-serif'],
      }
    },
  },
  plugins: [],
}
