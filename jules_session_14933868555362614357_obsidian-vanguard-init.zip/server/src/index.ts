import Fastify from 'fastify';
import socketio from 'fastify-socket.io';
import { PrismaClient } from '@prisma/client';
import { SocketEvents, ClassType, PlayerState } from '@obsidian-vanguard/shared';
import path from 'path';

const prisma = new PrismaClient();
const server = Fastify({ logger: true });

server.register(socketio, {
    cors: {
        origin: "*", // Allow all for dev
        methods: ["GET", "POST"]
    }
});

const players: Record<string, PlayerState> = {};

// Chaos Array Logic
let chaosArrayTimer = 0;
const CHAOS_ARRAY_INTERVAL = 10000; // 10 seconds for testing, should be 12 mins

setInterval(() => {
    chaosArrayTimer += 1000;
    if (chaosArrayTimer >= CHAOS_ARRAY_INTERVAL) {
        server.io.emit(SocketEvents.CHAOS_ARRAY_UPDATE, { active: true, duration: 5000 });
        chaosArrayTimer = 0;
        setTimeout(() => {
             server.io.emit(SocketEvents.CHAOS_ARRAY_UPDATE, { active: false });
        }, 5000);
    }
}, 1000);


server.ready(err => {
    if (err) throw err;

    server.io.on('connection', (socket) => {
        console.log('Client connected:', socket.id);

        socket.on(SocketEvents.JOIN_GAME, async (data: { name: string, classType: ClassType }) => {
            // Simplified character creation/loading for prototype
            // In prod, this would use JWT and load from DB
            
            // For now, create a temporary session state
            players[socket.id] = {
                id: socket.id,
                name: data.name,
                classType: data.classType,
                x: Math.random() * 800,
                y: Math.random() * 600,
                hp: 100,
                maxHp: 100
            };

            // Notify everyone
            socket.broadcast.emit(SocketEvents.PLAYER_JOINED, players[socket.id]);
            
            // Send current state to new player
            socket.emit(SocketEvents.JOIN_GAME, { players, id: socket.id });
        });

        socket.on(SocketEvents.PLAYER_MOVED, (data: { x: number, y: number }) => {
            if (players[socket.id]) {
                players[socket.id].x = data.x;
                players[socket.id].y = data.y;
                socket.broadcast.emit(SocketEvents.PLAYER_MOVED, { id: socket.id, x: data.x, y: data.y });
            }
        });
        
        socket.on(SocketEvents.DISCONNECT, () => {
            delete players[socket.id];
            server.io.emit(SocketEvents.PLAYER_LEFT, { id: socket.id });
        });
    });
});

const start = async () => {
    try {
        await server.listen({ port: 3000, host: '0.0.0.0' });
        console.log('Server started on port 3000');
    } catch (err) {
        server.log.error(err);
        process.exit(1);
    }
};

start();
